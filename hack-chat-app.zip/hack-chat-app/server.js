const express = require("express");
const http = require("http");
const path = require("path");
const helmet = require("helmet");
const session = require("express-session");
const SQLiteStoreFactory = require("connect-sqlite3");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = Number(process.env.PORT || 3000);
const secret = process.env.SESSION_SECRET;
if (!secret || secret.length < 32) {
  console.warn("WARNING: Set SESSION_SECRET to a random string of at least 32 characters before deployment.");
}
const SQLiteStore = SQLiteStoreFactory(session);
const dataDir = path.join(__dirname, "data");
require("fs").mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "hack-chat.db"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE COLLATE NOCASE,
 password_hash TEXT NOT NULL, display_name TEXT NOT NULL, bio TEXT NOT NULL DEFAULT '',
 avatar_color TEXT NOT NULL DEFAULT '#6875e8', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 banned INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS communities (
 id INTEGER PRIMARY KEY, name TEXT NOT NULL, owner_id INTEGER NOT NULL REFERENCES users(id),
 invite_code TEXT NOT NULL UNIQUE, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS memberships (
 community_id INTEGER NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 role TEXT NOT NULL DEFAULT 'member' CHECK(role IN ('owner','admin','moderator','member')),
 joined_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(community_id,user_id)
);
CREATE TABLE IF NOT EXISTS channels (
 id INTEGER PRIMARY KEY, community_id INTEGER NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
 name TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'text' CHECK(kind IN ('text','announcement')),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(community_id,name)
);
CREATE TABLE IF NOT EXISTS messages (
 id INTEGER PRIMARY KEY, channel_id INTEGER NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 body TEXT NOT NULL CHECK(length(body) <= 2000), created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS friendships (
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 friend_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 status TEXT NOT NULL CHECK(status IN ('pending','accepted')),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(user_id,friend_id), CHECK(user_id != friend_id)
);
CREATE TABLE IF NOT EXISTS mutes (
 community_id INTEGER NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 expires_at INTEGER NOT NULL, PRIMARY KEY(community_id,user_id)
);
CREATE INDEX IF NOT EXISTS idx_messages_channel_id ON messages(channel_id,id);
CREATE INDEX IF NOT EXISTS idx_memberships_user ON memberships(user_id);
`);

const store = new SQLiteStore({ db: "sessions.db", dir: dataDir, table: "sessions" });
app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "16kb" }));
const sessionMiddleware = session({
  store, name: "hackchat.sid", secret: secret || "development-only-change-this-secret-now",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.COOKIE_SECURE === "true", maxAge: 7 * 24 * 60 * 60 * 1000 }
});
app.use(sessionMiddleware);
app.use(express.static(path.join(__dirname, "public")));

const q = (sql) => db.prepare(sql);
const publicUser = u => u && ({ id:u.id, username:u.username, displayName:u.display_name, bio:u.bio, avatarColor:u.avatar_color });
function getUser(req) {
  if (!req.session.userId) return null;
  return q("SELECT * FROM users WHERE id=?").get(req.session.userId) || null;
}
function requireAuth(req,res,next) {
  const u = getUser(req);
  if (!u || u.banned) return res.status(401).json({ error: "Please sign in again." });
  req.user = u; next();
}
function membership(communityId,userId) {
  return q(`SELECT m.*, c.name community_name, c.owner_id FROM memberships m JOIN communities c ON c.id=m.community_id WHERE m.community_id=? AND m.user_id=?`).get(communityId,userId);
}
function canManage(role) { return ["owner","admin","moderator"].includes(role); }
function canAdmin(role) { return ["owner","admin"].includes(role); }
function cleanName(s, max=32) { return String(s || "").trim().replace(/\s+/g," ").slice(0,max); }
function validUsername(s) { return /^[a-zA-Z0-9_]{3,24}$/.test(s); }
function createCommunity(name, ownerId) {
  name = cleanName(name, 48);
  if (name.length < 2) throw new Error("Server name must be 2–48 characters.");
  const invite = crypto.randomBytes(5).toString("hex");
  const result = q("INSERT INTO communities(name,owner_id,invite_code) VALUES(?,?,?)").run(name, ownerId, invite);
  const id = result.lastInsertRowid;
  q("INSERT INTO memberships(community_id,user_id,role) VALUES(?,?,'owner')").run(id, ownerId);
  q("INSERT INTO channels(community_id,name,kind) VALUES(?, 'general', 'text'), (?, 'announcements', 'announcement')").run(id,id);
  return id;
}
function seed() {
  if (q("SELECT id FROM communities LIMIT 1").get()) return;
  let u = q("SELECT id FROM users ORDER BY id LIMIT 1").get();
  if (!u) {
    const hash = bcrypt.hashSync(crypto.randomBytes(32).toString("hex"), 10);
    const r = q("INSERT INTO users(username,password_hash,display_name) VALUES('community_bot',?,'Community Bot')").run(hash);
    u = {id:r.lastInsertRowid};
  }
  createCommunity("Welcome Hub", u.id);
}
seed();

app.get("/api/me", (req,res) => {
  const u = getUser(req);
  if (!u || u.banned) return res.json({ user:null });
  res.json({ user:publicUser(u) });
});
app.post("/api/register", async (req,res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  const displayName = cleanName(req.body.displayName || username, 32);
  if (!validUsername(username)) return res.status(400).json({error:"Username must be 3–24 letters, numbers, or underscores."});
  if (password.length < 10 || password.length > 128) return res.status(400).json({error:"Password must be 10–128 characters."});
  if (displayName.length < 2) return res.status(400).json({error:"Display name must be at least 2 characters."});
  try {
    const hash = await bcrypt.hash(password, 12);
    const r = q("INSERT INTO users(username,password_hash,display_name) VALUES(?,?,?)").run(username,hash,displayName);
    const id = Number(r.lastInsertRowid);
    createCommunity(`${displayName}'s corner`, id);
    req.session.userId = id;
    req.session.save(err => err ? res.status(500).json({error:"Could not start session."}) : res.json({user:publicUser(q("SELECT * FROM users WHERE id=?").get(id))}));
  } catch(e) {
    res.status(400).json({error: String(e.message).includes("UNIQUE") ? "That username is already taken." : "Could not create account."});
  }
});
app.post("/api/login", async (req,res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  const u = q("SELECT * FROM users WHERE username=? COLLATE NOCASE").get(username);
  if (!u || u.banned || !(await bcrypt.compare(password,u.password_hash))) return res.status(401).json({error:"Invalid username or password."});
  req.session.regenerate(err => {
    if (err) return res.status(500).json({error:"Could not start session."});
    req.session.userId = u.id;
    req.session.save(e => e ? res.status(500).json({error:"Could not save session."}) : res.json({user:publicUser(u)}));
  });
});
app.post("/api/logout", (req,res) => req.session.destroy(() => {res.clearCookie("hackchat.sid");res.json({ok:true});}));

app.use("/api", (req,res,next) => {
  if (["/me","/register","/login","/logout"].includes(req.path)) return next();
  requireAuth(req,res,next);
});

app.get("/api/bootstrap", (req,res) => {
  const user = req.user;
  const communities = q(`SELECT c.id,c.name,c.invite_code,m.role FROM communities c JOIN memberships m ON m.community_id=c.id WHERE m.user_id=? ORDER BY c.id`).all(user.id);
  const friends = q(`SELECT f.status, CASE WHEN f.user_id=? THEN f.friend_id ELSE f.user_id END friend_id,
    u.username,u.display_name,u.bio,u.avatar_color
    FROM friendships f JOIN users u ON u.id=CASE WHEN f.user_id=? THEN f.friend_id ELSE f.user_id END
    WHERE (f.user_id=? OR f.friend_id=?) AND u.banned=0 ORDER BY f.id`).all(user.id,user.id,user.id,user.id)
    .map(f=>({...f, userId:f.friend_id, displayName:f.display_name, avatarColor:f.avatar_color}));
  const pending = q(`SELECT f.user_id,u.username,u.display_name FROM friendships f JOIN users u ON u.id=f.user_id WHERE f.friend_id=? AND f.status='pending'`).all(user.id);
  const channels = q(`SELECT ch.id,ch.community_id,ch.name,ch.kind FROM channels ch JOIN memberships m ON m.community_id=ch.community_id WHERE m.user_id=? ORDER BY ch.id`).all(user.id);
  const members = {};
  for (const c of communities) members[c.id] = q(`SELECT u.id,u.username,u.display_name,u.avatar_color,m.role FROM memberships m JOIN users u ON u.id=m.user_id WHERE m.community_id=? AND u.banned=0 ORDER BY CASE m.role WHEN 'owner' THEN 0 WHEN 'admin' THEN 1 ELSE 2 END,u.username`).all(c.id).map(u=>({...u,displayName:u.display_name,avatarColor:u.avatar_color}));
  res.json({user:publicUser(user),communities,channels,friends,pending,members});
});

app.post("/api/communities", (req,res) => {
  try {
    const id=createCommunity(req.body.name,req.user.id);
    res.json({id,ok:true});
  } catch(e) { res.status(400).json({error:e.message}); }
});
app.post("/api/communities/join", (req,res) => {
  const code=String(req.body.inviteCode||"").trim();
  const c=q("SELECT * FROM communities WHERE invite_code=?").get(code);
  if(!c) return res.status(404).json({error:"Invite code not found."});
  q("INSERT OR IGNORE INTO memberships(community_id,user_id,role) VALUES(?,?,'member')").run(c.id,req.user.id);
  res.json({ok:true,communityId:c.id});
});
app.post("/api/communities/:id/channels", (req,res) => {
  const id=Number(req.params.id), m=membership(id,req.user.id);
  if(!m || !canManage(m.role)) return res.status(403).json({error:"Moderator permission required."});
  const name=String(req.body.name||"").trim().toLowerCase().replace(/[^a-z0-9-]/g,"-").replace(/-+/g,"-").slice(0,40);
  if(name.length<2) return res.status(400).json({error:"Channel name must be at least 2 characters."});
  try {
    const r=q("INSERT INTO channels(community_id,name,kind) VALUES(?,?,?)").run(id,name,req.body.kind==="announcement"?"announcement":"text");
    res.json({id:Number(r.lastInsertRowid),name});
  } catch { res.status(400).json({error:"That channel already exists."}); }
});
app.get("/api/channels/:id/messages", (req,res) => {
  const channelId=Number(req.params.id);
  const c=q("SELECT * FROM channels WHERE id=?").get(channelId);
  if(!c || !membership(c.community_id,req.user.id)) return res.status(403).json({error:"You are not a member of this channel."});
  const before=Number(req.query.before||Number.MAX_SAFE_INTEGER);
  const messages=q(`SELECT m.id,m.body,m.created_at,u.id user_id,u.username,u.display_name,u.avatar_color
    FROM messages m JOIN users u ON u.id=m.user_id WHERE m.channel_id=? AND m.id<? ORDER BY m.id DESC LIMIT 100`).all(channelId,before).reverse()
    .map(m=>({...m, userId:m.user_id, displayName:m.display_name, avatarColor:m.avatar_color, createdAt:m.created_at}));
  res.json({messages});
});
app.patch("/api/profile", (req,res) => {
  const displayName=cleanName(req.body.displayName,32), bio=String(req.body.bio||"").trim().slice(0,160);
  if(displayName.length<2) return res.status(400).json({error:"Display name must be at least 2 characters."});
  q("UPDATE users SET display_name=?,bio=? WHERE id=?").run(displayName,bio,req.user.id);
  res.json({user:publicUser(q("SELECT * FROM users WHERE id=?").get(req.user.id))});
});
app.post("/api/friends/request", (req,res) => {
  const username=String(req.body.username||"").trim();
  const friend=q("SELECT id FROM users WHERE username=? COLLATE NOCASE AND banned=0").get(username);
  if(!friend) return res.status(404).json({error:"User not found."});
  if(friend.id===req.user.id) return res.status(400).json({error:"You cannot add yourself."});
  const existing=q("SELECT * FROM friendships WHERE (user_id=? AND friend_id=?) OR (user_id=? AND friend_id=?)").get(req.user.id,friend.id,friend.id,req.user.id);
  if(existing) {
    if(existing.status==="pending" && existing.friend_id===req.user.id) {
      q("UPDATE friendships SET status='accepted' WHERE user_id=? AND friend_id=?").run(friend.id,req.user.id);
      return res.json({ok:true,accepted:true});
    }
    return res.status(400).json({error:"A friend request or friendship already exists."});
  }
  q("INSERT INTO friendships(user_id,friend_id,status) VALUES(?,?,'pending')").run(req.user.id,friend.id);
  res.json({ok:true});
});
app.post("/api/friends/accept", (req,res) => {
  const id=Number(req.body.userId);
  const r=q("UPDATE friendships SET status='accepted' WHERE user_id=? AND friend_id=? AND status='pending'").run(id,req.user.id);
  if(!r.changes) return res.status(404).json({error:"Request not found."});
  res.json({ok:true});
});
app.delete("/api/friends/:id", (req,res) => {
  const id=Number(req.params.id);
  q("DELETE FROM friendships WHERE (user_id=? AND friend_id=?) OR (user_id=? AND friend_id=?)").run(req.user.id,id,id,req.user.id);
  res.json({ok:true});
});
app.post("/api/communities/:id/roles", (req,res) => {
  const communityId=Number(req.params.id), actor=membership(communityId,req.user.id), targetId=Number(req.body.userId), role=String(req.body.role);
  if(!actor || !canAdmin(actor.role)) return res.status(403).json({error:"Only the owner or an admin can change roles."});
  if(!["admin","moderator","member"].includes(role)) return res.status(400).json({error:"Invalid role."});
  const target=membership(communityId,targetId);
  if(!target || target.role==="owner") return res.status(400).json({error:"Cannot change this member's role."});
  q("UPDATE memberships SET role=? WHERE community_id=? AND user_id=?").run(role,communityId,targetId);
  res.json({ok:true});
});
app.post("/api/communities/:id/moderation", (req,res) => {
  const communityId=Number(req.params.id), actor=membership(communityId,req.user.id);
  if(!actor || !canManage(actor.role)) return res.status(403).json({error:"Moderator permission required."});
  const targetId=Number(req.body.userId), action=String(req.body.action||"");
  const target=membership(communityId,targetId);
  if(!target) return res.status(404).json({error:"Member not found."});
  if(target.role==="owner" || targetId===req.user.id) return res.status(400).json({error:"You cannot moderate this member."});
  if(action==="kick" || action==="ban") {
    q("DELETE FROM memberships WHERE community_id=? AND user_id=?").run(communityId,targetId);
    if(action==="ban") {
      // Ban from this community by deleting membership; global account bans are owner-only and not exposed here.
    }
    io.to(`user:${targetId}`).emit("membership-removed",{communityId});
  } else if(action==="mute") {
    const minutes=Math.max(1,Math.min(1440,Number(req.body.minutes)||10));
    q("INSERT INTO mutes(community_id,user_id,expires_at) VALUES(?,?,?) ON CONFLICT(community_id,user_id) DO UPDATE SET expires_at=excluded.expires_at").run(communityId,targetId,Date.now()+minutes*60000);
  } else if(action==="unmute") {
    q("DELETE FROM mutes WHERE community_id=? AND user_id=?").run(communityId,targetId);
  } else return res.status(400).json({error:"Unknown moderation action."});
  res.json({ok:true});
});
app.use((err,req,res,next) => {
  console.error(err);
  res.status(500).json({error:"Something went wrong. Please try again."});
});

// Reuse the exact Express session middleware for Socket.IO's HTTP engine requests.
io.engine.use(sessionMiddleware);
io.use((socket,next) => {
  const sid=socket.request.session;
  if(!sid || !sid.userId) return next(new Error("Sign in required"));
  const user=q("SELECT * FROM users WHERE id=?").get(sid.userId);
  if(!user || user.banned) return next(new Error("Sign in required"));
  socket.user=user; next();
});
const rateMap = new Map();
io.on("connection", socket => {
  const userId=socket.user.id;
  socket.join(`user:${userId}`);
  const memberRooms = q("SELECT community_id FROM memberships WHERE user_id=?").all(userId);
  memberRooms.forEach(m=>socket.join(`community:${m.community_id}`));
  socket.on("join-channel", channelId => {
    const id=Number(channelId), c=q("SELECT * FROM channels WHERE id=?").get(id);
    if(!c || !membership(c.community_id,userId)) return;
    socket.join(`channel:${id}`);
  });
  socket.on("leave-channel", channelId => socket.leave(`channel:${Number(channelId)}`));
  socket.on("send-message", payload => {
    try {
      const now=Date.now(), prev=rateMap.get(userId)||[];
      const recent=prev.filter(t=>now-t<10000);
      if(recent.length>=8) return socket.emit("chat-error",{message:"Slow down a little before sending more messages."});
      rateMap.set(userId,[...recent,now]);
      const channelId=Number(payload?.channelId), body=String(payload?.body||"").trim();
      if(!body || body.length>2000) return socket.emit("chat-error",{message:"Messages must be 1–2000 characters."});
      const c=q("SELECT * FROM channels WHERE id=?").get(channelId);
      const m=c && membership(c.community_id,userId);
      if(!c || !m) return socket.emit("chat-error",{message:"You do not have access to that channel."});
      const mute=q("SELECT expires_at FROM mutes WHERE community_id=? AND user_id=?").get(c.community_id,userId);
      if(mute && mute.expires_at>Date.now()) return socket.emit("chat-error",{message:"You are muted in this server."});
      if(mute) q("DELETE FROM mutes WHERE community_id=? AND user_id=?").run(c.community_id,userId);
      const r=q("INSERT INTO messages(channel_id,user_id,body) VALUES(?,?,?)").run(channelId,userId,body);
      const msg=q(`SELECT m.id,m.body,m.created_at,u.id user_id,u.username,u.display_name,u.avatar_color FROM messages m JOIN users u ON u.id=m.user_id WHERE m.id=?`).get(r.lastInsertRowid);
      const out={id:msg.id,body:msg.body,createdAt:msg.created_at,userId:msg.user_id,username:msg.username,displayName:msg.display_name,avatarColor:msg.avatar_color};
      io.to(`channel:${channelId}`).emit("new-message",out);
    } catch(e) { socket.emit("chat-error",{message:"Could not send that message."}); }
  });
});

server.listen(PORT, () => console.log(`HACK CHAT running at http://localhost:${PORT}`));
