# HACK CHAT — Discord-inspired realtime community app

A runnable starter project with a responsive web UI, user accounts, server/community creation, invite codes, text channels, persistent realtime messages, friends, profiles, roles and basic moderation.

## Requirements
- Node.js 20 or newer
- npm

## Run locally
1. Extract this ZIP.
2. Open a terminal in the `hack-chat-app` folder.
3. Install dependencies: `npm install`
4. Copy `.env.example` to `.env`.
5. Put a long random value (32+ characters) in `SESSION_SECRET`.
6. Start: `npm start`
7. Open `http://localhost:3000`

The SQLite database and session store are created in `data/` on first run. Keep that directory backed up if you want to preserve accounts and messages.

## Features included
- Register/login with bcrypt password hashing and server-side sessions
- Responsive dark interface for desktop and mobile web
- Create communities and join using invite codes
- Text and announcement channels
- Persistent message history and live delivery with Socket.IO
- Friends requests, accept, remove
- Editable display name and bio
- Owner/admin/moderator/member roles
- Role assignment (owner/admin only), kick, timed mute/unmute
- Basic request/message validation, session cookie settings, Helmet headers

## Important limits
This is a starter, not a production-hardened Discord replacement. It does not yet include direct-message conversations, file uploads, push notifications, message editing/deletion, searchable history, voice/video, OAuth, email verification, password reset, or a full audit log. The current “ban” moderation action removes a member from that community; it is not a global account ban. Do not expose it publicly until you have added the hardening checklist below.

## Deployment checklist
- Use HTTPS and set `COOKIE_SECURE=true`.
- Set a unique, strong `SESSION_SECRET` using your host's secret manager; never commit `.env`.
- Use a persistent disk for `data/` or migrate SQLite to PostgreSQL for multiple instances.
- Add CSRF protection/origin checks, login/register rate limits, email verification, password reset, account deletion, abuse reporting, moderator audit logs, and automated backups.
- Add server-side authorization tests and security review before inviting the public.
- For multiple server instances, replace SQLite sessions and in-memory message rate limiting with shared infrastructure (e.g. Redis) and use a shared database.
- Voice/video requires a separate real-time media system (such as a WebRTC SFU); Socket.IO chat does not provide voice/video.

## Configuration
Copy `.env.example` to `.env` and configure:
- `PORT`: web server port (default 3000)
- `SESSION_SECRET`: random secret, at least 32 characters
- `NODE_ENV`: set to `production` on deployment
- `COOKIE_SECURE`: set `true` behind HTTPS

## First account / community
Create an account in the UI. Registration automatically creates a personal community with `general` and `announcements` channels. Each community's invite code is available under the server menu or Invite people. Treat invite codes as private.
